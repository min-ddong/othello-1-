# Name: mingyeong kim
# Date: 8/24/2023
# File Purpose: Lab01 main program driver program

from hello import *

print("*** TUFFY TITAN HELLO PROGRAM ***")

print(helloworld())

print(helloname("steve"))
