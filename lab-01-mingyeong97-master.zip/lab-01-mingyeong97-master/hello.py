# Name: mingyeong kim
# Date: 8/24/2023
# File Purpose: Multiple hello functions

def helloworld():
    return "Hello World!"


def helloname(name):
    return "Hello " + name + "!"
